//
//  isCompleted+Convenience.swift
//  Task-CoreData
//
//  Created by Delstun McCray on 7/27/21.
//

import CoreData

extension DidComplete {
    
    @discardableResult
    convenience init(date: Date, task: Task, context: NSManagedObjectContext = CoreDataStack.context) {
        self.init(context: context)
        self.date = date
        self.task = task
    }
}
