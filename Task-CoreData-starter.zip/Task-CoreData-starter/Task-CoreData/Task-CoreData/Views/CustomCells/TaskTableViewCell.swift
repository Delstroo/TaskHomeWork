//
//  TaskTableViewCell.swift
//  Task-CoreData
//
//  Created by Delstun McCray on 7/27/21.
//

import UIKit


protocol TaskCellDelegate: AnyObject {
    func taskCellButtonTapped(_ sender: TaskTableViewCell)
}

class TaskTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var isComplete: UIButton!
    
    var task: Task? {
        didSet {
            updateViews()
        }
    }
    
    //MARK: - Properties
    
    weak var delegate: TaskCellDelegate?
    
    //MARK: - Actions
    @IBAction func isCompleteButtonTapped(_ sender: Any) {
        if let delegate = delegate {
            delegate.taskCellButtonTapped(self)
        }

    }
    
    //MARK: - Helper Methods
    
    func updateViews() {
        guard let task = task else { return }
        titleLabel.text = task.name
        if task.isComplete {
            isComplete.setBackgroundImage(UIImage(named: "complete"), for: .normal)
        } else {
            isComplete.setBackgroundImage(UIImage(named: "incomplete"), for: .normal)
        }
    }

}//End Of Class
