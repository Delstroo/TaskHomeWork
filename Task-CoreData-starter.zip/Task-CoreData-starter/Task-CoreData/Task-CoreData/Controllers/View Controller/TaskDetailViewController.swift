//
//  TaskDetailViewController.swift
//  Task-CoreData
//
//  Created by Delstun McCray on 7/27/21.
//

import UIKit

class TaskDetailViewController: UIViewController {

    //MARK: - Outlets
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notesTextView: UITextView!
    @IBOutlet weak var datePicker: UIDatePicker!

    //MARK: - Properties
    var task: Task?
    var date: Date?
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()

    }
//MARK: - Actions
   
    @IBAction func saveButtonTapped(_ sender: Any) {
        guard let name = nameTextField.text, !name.isEmpty else { return }
        if let task = task {
            TaskController.shared.updateTaskDetails(task: task, name: name, notes: notesTextView.text, dueDate: datePicker.date)
        } else {
            TaskController.shared.createTask(name: name, notes: notesTextView.text, dueDate: datePicker.date)
        }
        navigationController?.popViewController(animated: true)
    }
  
    @IBAction func dueDatePickerDateChanged(_ sender: Any) {
        self.date = datePicker.date
    }
    
    func updateViews() {
        guard let task = task else { return }
        nameTextField.text = task.name
        notesTextView.text = task.notes
        datePicker.date = task.dueDate ?? Date()
    }


}
